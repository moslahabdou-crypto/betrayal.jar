package com.betrayal;

import com.betrayal.entity.BetrayalEntity;
import com.betrayal.entity.BetrayalGhostEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(BetrayalMod.MODID)
public class BetrayalMod {
    public static final String MODID = "betrayal";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);

    public static final RegistryObject<Item> KNIFE = ITEMS.register("knife",
            () -> new SwordItem(KnifeTier.INSTANCE, 1, -1.5F, new Item.Properties().stacksTo(1)));

    public static final RegistryObject<EntityType<BetrayalEntity>> BETRAYED = ENTITIES.register("betrayal",
            () -> EntityType.Builder.of(BetrayalEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(10).build("betrayal"));

    public static final RegistryObject<EntityType<BetrayalGhostEntity>> GHOST = ENTITIES.register("betrayed_ghost",
            () -> EntityType.Builder.of(BetrayalGhostEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F).fireImmune().clientTrackingRange(10).updateInterval(1).build("betrayed_ghost"));

    public static final RegistryObject<SoundEvent> SCARY_VOICE = SOUNDS.register("scary_voice",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MODID, "scary_voice")));

    public BetrayalMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        ENTITIES.register(bus);
        SOUNDS.register(bus);
        bus.addListener(this::commonSetup);
        bus.addListener(this::attributes);
        bus.addListener(this::tabs);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(BetrayalNetwork::register);
    }

    private void attributes(EntityAttributeCreationEvent e) {
        e.put(BETRAYED.get(), BetrayalEntity.createAttributes().build());
        e.put(GHOST.get(), BetrayalGhostEntity.createAttributes().build());
    }

    private void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT) {
            e.accept(KNIFE);
        }
    }
}
