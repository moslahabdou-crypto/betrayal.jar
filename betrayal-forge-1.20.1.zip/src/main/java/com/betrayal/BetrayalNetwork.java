package com.betrayal;

import com.betrayal.client.ClientEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class BetrayalNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(BetrayalMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.registerMessage(0, JumpscarePacket.class, JumpscarePacket::encode, JumpscarePacket::decode, JumpscarePacket::handle);
    }

    /** Server -> client: flash the monster's face on the whole screen. */
    public static class JumpscarePacket {
        public static void encode(JumpscarePacket msg, FriendlyByteBuf buf) {}

        public static JumpscarePacket decode(FriendlyByteBuf buf) { return new JumpscarePacket(); }

        public static void handle(JumpscarePacket msg, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() ->
                    DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientEvents::jumpscare));
            ctx.get().setPacketHandled(true);
        }
    }
}
