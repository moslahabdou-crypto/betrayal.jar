package com.betrayal;

import com.betrayal.entity.BetrayalEntity;
import com.betrayal.entity.BetrayalGhostEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server-side game logic: knife, follower, nightly haunting. State lives in the player's persistent data. */
@Mod.EventBusSubscriber(modid = BetrayalMod.MODID)
public class BetrayalEvents {
    private static final String GIVEN = "betrayal_given";
    private static final String KILLED = BetrayalEntity.KILLED_KEY;
    private static final String HAUNT = "betrayal_haunt";
    private static final String DAY = "betrayal_day";
    private static final String[] KEYS = {GIVEN, KILLED, HAUNT, DAY};

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            CompoundTag d = p.getPersistentData();
            if (!d.getBoolean(GIVEN)) {
                d.putBoolean(GIVEN, true);
                giveKnife(p);
            }
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            giveKnife(p);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        CompoundTag from = e.getOriginal().getPersistentData();
        CompoundTag to = e.getEntity().getPersistentData();
        for (String k : KEYS) {
            if (from.contains(k)) to.put(k, from.get(k).copy());
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            p.getPersistentData().putBoolean(HAUNT, false); // the haunting ends when you die
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 0 || !p.isAlive()) return;

        CompoundTag d = p.getPersistentData();
        ServerLevel level = p.serverLevel();

        if (!d.getBoolean(KILLED)) {
            ensureFollower(p, level);
            return;
        }

        // Each new night (overworld) the spirit comes for you.
        if (!d.getBoolean(HAUNT) && level.dimension() == Level.OVERWORLD) {
            long time = level.getDayTime();
            long day = time / 24000L + 1L;
            long tod = time % 24000L;
            if (tod >= 13000L && tod < 23000L && d.getLong(DAY) != day) {
                d.putBoolean(HAUNT, true);
                d.putLong(DAY, day);
                p.sendSystemMessage(Component.literal("He is here...").withStyle(ChatFormatting.DARK_RED));
            }
        }

        if (d.getBoolean(HAUNT) && level.getEntitiesOfClass(BetrayalGhostEntity.class,
                p.getBoundingBox().inflate(64.0D), g -> p.getUUID().equals(g.getOwnerId())).isEmpty()) {
            spawnGhost(p, level);
        }
    }

    private static void giveKnife(ServerPlayer p) {
        for (ItemStack s : p.getInventory().items) {
            if (s.is(BetrayalMod.KNIFE.get())) return;
        }
        if (p.getOffhandItem().is(BetrayalMod.KNIFE.get())) return;
        ItemStack knife = new ItemStack(BetrayalMod.KNIFE.get());
        if (!p.getInventory().add(knife)) {
            p.drop(knife, false);
        }
    }

    private static void ensureFollower(ServerPlayer p, ServerLevel level) {
        boolean has = !level.getEntitiesOfClass(BetrayalEntity.class, p.getBoundingBox().inflate(48.0D),
                z -> p.getUUID().equals(z.getOwnerId())).isEmpty();
        if (has) return;
        BetrayalEntity z = BetrayalMod.BETRAYED.get().create(level);
        if (z == null) return;
        z.setOwnerId(p.getUUID());
        z.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), 0.0F);
        level.addFreshEntity(z);
    }

    private static void spawnGhost(ServerPlayer p, ServerLevel level) {
        BetrayalGhostEntity g = BetrayalMod.GHOST.get().create(level);
        if (g == null) return;
        g.setOwnerId(p.getUUID());
        Vec3 pos = p.position().add(Vec3.directionFromRotation(0.0F, p.getYRot()).scale(8.0D));
        g.moveTo(pos.x, pos.y, pos.z, 0.0F, 0.0F);
        level.addFreshEntity(g);
    }
}
