package com.betrayal.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.betrayal.BetrayalMod;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = BetrayalMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {
    private static final ResourceLocation FACE = new ResourceLocation(BetrayalMod.MODID, "textures/gui/jumpscare.png");
    private static final int FLASH_TICKS = 14; // how long the face stays on screen (0.7 s)

    private static long showUntil = -1L;

    /** Called when the server sends a jumpscare packet. */
    public static void jumpscare() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) {
            showUntil = mc.level.getGameTime() + FLASH_TICKS;
        }
    }

    private static final IGuiOverlay FACE_OVERLAY = (gui, graphics, partialTick, width, height) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.getGameTime() > showUntil) return;
        RenderSystem.enableBlend();
        graphics.blit(FACE, 0, 0, width, height, 0.0F, 0.0F, 128, 128, 128, 128);
    };

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(BetrayalMod.BETRAYED.get(), BetrayalRenderer::new);
        e.registerEntityRenderer(BetrayalMod.GHOST.get(), BetrayalGhostRenderer::new);
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("betrayal_face", FACE_OVERLAY);
    }
}
