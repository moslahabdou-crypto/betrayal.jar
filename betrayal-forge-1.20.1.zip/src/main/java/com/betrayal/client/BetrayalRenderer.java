package com.betrayal.client;

import com.betrayal.BetrayalMod;
import com.betrayal.entity.BetrayalEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BetrayalRenderer extends HumanoidMobRenderer<BetrayalEntity, PlayerModel<BetrayalEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(BetrayalMod.MODID, "textures/entity/betrayed.png");

    public BetrayalRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(BetrayalEntity entity) {
        return TEXTURE;
    }
}
