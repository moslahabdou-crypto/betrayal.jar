package com.betrayal.client;

import com.betrayal.BetrayalMod;
import com.betrayal.entity.BetrayalGhostEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Renders the ghost with a see-through skin. */
public class BetrayalGhostRenderer extends HumanoidMobRenderer<BetrayalGhostEntity, PlayerModel<BetrayalGhostEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(BetrayalMod.MODID, "textures/entity/betrayed_ghost.png");

    public BetrayalGhostRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.0F);
    }

    @Override
    public ResourceLocation getTextureLocation(BetrayalGhostEntity entity) {
        return TEXTURE;
    }

    @Override
    protected RenderType getRenderType(BetrayalGhostEntity entity, boolean visible, boolean translucent, boolean glowing) {
        return RenderType.entityTranslucent(TEXTURE);
    }
}
