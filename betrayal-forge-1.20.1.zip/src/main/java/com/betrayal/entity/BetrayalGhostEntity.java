package com.betrayal.entity;

import com.betrayal.BetrayalMod;
import com.betrayal.BetrayalNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.UUID;

/**
 * Betrayal's spirit. Floats in front of its victim, gives blindness, plays the scary voice,
 * and every 2 seconds flashes its face on the screen and hurts the player until they die.
 */
public class BetrayalGhostEntity extends PathfinderMob {
    private static final int PULSE_TICKS = 40;   // every 2 seconds
    private static final float PULSE_DAMAGE = 4.0F; // 2 hearts
    private static final int SOUND_TICKS = 90;   // scary_voice.ogg is ~4.2 s long

    private UUID ownerId;

    public BetrayalGhostEntity(EntityType<? extends BetrayalGhostEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 1.0D);
    }

    public UUID getOwnerId() { return ownerId; }

    public void setOwnerId(UUID id) { this.ownerId = id; }

    @Override
    public boolean shouldBeSaved() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public boolean hurt(DamageSource source, float amount) { return false; }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean isAttackable() { return false; }

    @Override
    public void tick() {
        this.noPhysics = true;
        super.tick();
        this.setNoGravity(true);
        this.setDeltaMovement(Vec3.ZERO);
        if (level().isClientSide) return;

        ServerPlayer player = ownerId == null ? null
                : ((net.minecraft.server.level.ServerLevel) level()).getServer().getPlayerList().getPlayer(ownerId);
        if (player == null || !player.isAlive() || player.level() != level()) {
            discard();
            return;
        }

        // Float in front of the player, slightly bobbing.
        Vec3 dir = Vec3.directionFromRotation(0.0F, player.getYRot());
        Vec3 target = player.position().add(dir.scale(3.0D)).add(0.0D, 0.2D + 0.2D * Math.sin(tickCount * 0.15D), 0.0D);
        Vec3 delta = target.subtract(position());
        double len = delta.length();
        if (len > 0.01D) {
            double step = Math.min(len, Math.max(0.15D, len * 0.1D));
            Vec3 next = position().add(delta.scale(step / len));
            this.setPos(next.x, next.y, next.z);
        }

        // Always stare at the player.
        float yaw = (float) (Mth.atan2(player.getZ() - getZ(), player.getX() - getX()) * (180.0D / Math.PI)) - 90.0F;
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.yHeadRot = yaw;
        this.setXRot(0.0F);

        if (tickCount % SOUND_TICKS == 1) {
            level().playSound(null, getX(), getY(), getZ(), BetrayalMod.SCARY_VOICE.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
        }
        if (tickCount == 1 || tickCount % PULSE_TICKS == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 0, false, false));
        }
        if (tickCount > 0 && tickCount % PULSE_TICKS == 0) {
            player.hurt(player.damageSources().magic(), PULSE_DAMAGE);
            BetrayalNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new BetrayalNetwork.JumpscarePacket());
        }
    }
}
