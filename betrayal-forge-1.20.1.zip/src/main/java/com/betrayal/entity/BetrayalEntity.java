package com.betrayal.entity;

import com.betrayal.BetrayalMod;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.EnumSet;
import java.util.UUID;

/** The innocent Betrayal: follows the player around. Killing him with the knife starts the haunting. */
public class BetrayalEntity extends PathfinderMob {
    public static final String KILLED_KEY = "betrayal_killed";

    private UUID ownerId;

    public BetrayalEntity(EntityType<? extends BetrayalEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D);
    }

    public UUID getOwnerId() { return ownerId; }

    public void setOwnerId(UUID id) { this.ownerId = id; }

    private Player getOwner() {
        return ownerId == null ? null : level().getPlayerByUUID(ownerId);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    /** Not saved: BetrayalEvents re-creates him next to the player when needed, so no duplicates. */
    @Override
    public boolean shouldBeSaved() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount % 20 == 0 && getOwner() == null) {
            discard();
        }
    }

    /** Only a player holding the knife can hurt him. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        if (source.getEntity() instanceof Player p && p.getMainHandItem().is(BetrayalMod.KNIFE.get())) {
            return super.hurt(source, amount);
        }
        return false;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && source.getEntity() instanceof ServerPlayer killer) {
            killer.getPersistentData().putBoolean(KILLED_KEY, true);
            killer.sendSystemMessage(Component.literal("You killed an innocent soul. He will come for you tonight.")
                    .withStyle(ChatFormatting.DARK_RED));
        }
    }

    private static class FollowOwnerGoal extends Goal {
        private final BetrayalEntity mob;
        private Player owner;
        private int recalc;

        FollowOwnerGoal(BetrayalEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            owner = mob.getOwner();
            return owner != null && mob.distanceToSqr(owner) > 9.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && mob.distanceToSqr(owner) > 4.0D;
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            mob.getLookControl().setLookAt(owner, 30.0F, 30.0F);
            if (--recalc > 0) return;
            recalc = 10;
            if (mob.distanceToSqr(owner) > 400.0D) {
                mob.moveTo(owner.getX(), owner.getY(), owner.getZ(), owner.getYRot(), 0.0F);
                mob.getNavigation().stop();
            } else {
                mob.getNavigation().moveTo(owner, 1.1D);
            }
        }
    }
}
