package com.betrayal;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Knife tier: 0 uses = the knife never breaks. */
public enum KnifeTier implements Tier {
    INSTANCE;

    @Override public int getUses() { return 0; }
    @Override public float getSpeed() { return 1.0F; }
    @Override public float getAttackDamageBonus() { return 2.0F; }
    @Override public int getLevel() { return 2; }
    @Override public int getEnchantmentValue() { return 0; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
}
