# Betrayal (Forge 1.20.1)

Build: `./gradlew build` (JDK 17) -> `build/libs/betrayal-1.0.0.jar`, put it in `mods/`.
No local JDK? Push this folder to GitHub: the Actions tab builds the JAR for you (artifact `betrayal-jar`).

Tuning (top of `BetrayalGhostEntity.java`): PULSE_TICKS (face every 2 s), PULSE_DAMAGE.
Replace `assets/betrayal/textures/gui/jumpscare.png` with any 128x128 face image.
